
void readImages() {
    for (int i=1; i<=20; i++) {
      String imageNum  = nf(i, 2);
      String imageFile = "yellow/yellow"+imageNum+".png";
      imageList[i] = loadImage(imageFile);
      println("imageList["+i+"]", "loaded PImage with", imageFile);
  }
}
