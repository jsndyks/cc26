// -- Wobblers - inspired by kusakari
//    https://openprocessing.org/sketch/1975272

ArrayList<Wobbler> wobblers = new ArrayList<Wobbler>();

float size ; // <-- Max cell size

// -- Arrays to hold the number of times each week is selected:
int [] week1 = new int [53];  // <-- 53 as I am going to use 1-52
int [] week2 = new int [53];
int [] week3 = new int [53];
int [] weeks = new int [53];

// -- Wobbler number and layout:
int rows =  4;  // <-- number of rows in the grid
int cols = 13;  // <-- number of columns in the grid
int num =  52;  // <-- maximum number of wobblers

// -- Store images:
PImage [] imageList = new PImage[21];
  
// -- System state variables:
boolean wobble       = true;
boolean wobbleScale  = false;
boolean seedOn       = false;
boolean weekSize     = false;
boolean numbers      = false;
boolean bars         = false;
boolean showFlowers  = false;
boolean showCircles  = false;
boolean showSquares  = true;
boolean showDots     = true;
boolean veraFill     = false;

// -- Wobble (noise) scaling:
float wobbleSF = 1;

void setup () {

  size(1300, 420);

  size=0.85*width/(cols);

  // -- Use a method to read the data into the "week" arrays:
  readData();
  
  // -- Use a method to read imagews from file into an array:
  readImages();

  textAlign(CENTER, CENTER);
  textSize(18);

  int i=0;
  for (int r=0; r<rows; r++) {
    for (int c=0; c<cols; c++) {
      i++;
      if (i<=num) {
        // -- Cell positions and wobbler 'velocity' based on values in 'weeks':
        float x= map(c, 0, cols-1, width*0.05, width*0.95) ;
        float y= map(r, 0, rows-1, height*0.15, height*0.85)  ;
        float v= map(pow(weeks[i], 1.5), 0, pow(max(weeks), 1.5), 0.0, 3);
        // -- Add a wobbler with these characteristics to the ArrayList:
        wobblers.add(new Wobbler(x, y, size, v, i));
      }
    }
  }
}


void draw() {

  // -- Love a simple draw() loop!
  background(255);

  // -- Option to randomise each time draw() runs, or use consistent random numbers:
  if (seedOn) {
    randomSeed(4488);  // <-- the number doesn't matter, this just ensures the same 'random' numbers each time draw is called
  }

  // -- Loop through the ArrayList and draw the wobblers!
  for (Wobbler w : wobblers) {
    w.draw();
  }
}

void mouseMoved () {
  if (wobbleScale) {
    wobbleSF = map (mouseX, 0, width, 0.5, 5.0);
  } else {
    wobbleSF = 1;
  }
}
