// -- System state variables - switch on key press
// -- These are acted on in the draw() loop.

void keyPressed() {
  if (key == ' ') seedOn       = !seedOn;
  if (key == 's') weekSize     = !weekSize;
  if (key == 'w') wobble       = !wobble;
  if (key == 'm') wobbleScale  = !wobbleScale;
  if (key == 'n') numbers      = !numbers;
  if (key == 'b') bars         = !bars;
  if (key == 'f') showFlowers  = !showFlowers;
  if (key == 'c') showCircles  = !showCircles;
  if (key == 'd') showDots     = !showDots;
  if (key == 'q') showSquares  = !showSquares;
  if (key == 'v') veraFill     = !veraFill;
}
