
class Wobbler {

  // -- Data fields that define each instance of a Wobbler!
  PVector p;  // <-- position
  float v;    // <-- velocity - speed of wobble
  int n;      // <-- the number of the Wobbler in the Arraylist

  // -- Constructor - always runs when a Wobbler is instantiated:
  Wobbler (float x, float y, float sze, float vel, int num) {
    p = new PVector(x, y, sze);
    v = map(vel, 0, 1, 0.001, 0.1);
    n=num;
  }

  void draw () {
    rectMode(CENTER);
    imageMode(CENTER);
    pushMatrix();

    float rZ = p.z;  // <-- the 'radius' or size of the Wobbler

    if (weekSize) {
      // -- Base size on the number in the weeks array:
      rZ=map(sqrt(weeks[n]), 0, sqrt(max(weeks)), 0, p.z*1.45);
    }

    // -- Use this for calculating edges of rectangle:
    float halfSize=rZ*0.5;

    // -- rectangle:
    translate(p.x, p.y);
    noFill();
    stroke(64, 196);
    if (!(showCircles || showSquares)) {
      rect(0, 0, rZ, rZ);
    }

    // -- Add interaction if mouse is in rect:
    if (mouseX>p.x-halfSize && mouseX<p.x+halfSize && mouseY >p.y-halfSize && mouseY<p.y+halfSize) {
      fill(32, 200);
      text(weeks[n], 25, -25);
      fill(255, 255, 0, 200);
    }

    if (wobble) {
      // -- Draw the Wobbler: four triangles
      // noise point:
      float tX = map(noise(n+frameCount*v*wobbleSF, 0), 0, 1, -halfSize, halfSize);
      float tY = map(noise(0, n+frameCount*v*wobbleSF), 0, 1, -halfSize, halfSize);

      // triangles: triangle(x1, y1, x2, y2, x3, y3)
      fill(32, 128, 64);
      fill(162, 70, 79);
      triangle(tX, tY, -halfSize, -halfSize, halfSize, -halfSize);

      fill(255, 255, 32);
      fill(122, 141, 86);
      triangle(tX, tY, halfSize, -halfSize, halfSize, halfSize);

      fill(96, 96, 32);
      fill(235, 177, 75);
      triangle(tX, tY, halfSize, halfSize, -halfSize, halfSize);

      fill(0);
      triangle(tX, tY, -halfSize, halfSize, -halfSize, -halfSize);

      if (numbers) {
        fill(250);
        text(n, 0, 0);
      }
    } else {
      float bMax = max(weeks);

      // -- Draw the circles: one for each number in week [n]
      float halfSizeGap=rZ*0.45;
      noStroke();
      if (numbers) {
        fill(16, 64, 32, 200);
        text(n, 0, 0);
      }

      if (showFlowers) {
        int i = weeks[n];
        //println("image:", n, i, imageList[i]);
        if (i>0) {
          image(imageList[i], 0, 0, rZ, rZ);
        }
      }

      if (bars) {
        //println(bMax);
        fill(255, 128, 64, 128);
        float z = map(weeks[n], 0, bMax, 0, rZ);
        float yTop = -halfSize + z/2f + (rZ-z);
        rect(0, yTop, rZ, z);
      }

      if (showCircles) {
        float  dRnX = map(mouseX, 0, width, 0, 15);
        float  dRnY = map(mouseY, 0, height, 0, 15);
        for (int i=0; i<weeks[n]; i++) {
          float d = map(i, 0, bMax, rZ-2, 2);
          float dW = d+random(-dRnY, dRnY);
          float dH = d+random(-dRnX, dRnX);
          noFill();
          stroke(random(8, 128), random(128, 255));
          ellipse(random(-dRnX, dRnX), random(-dRnY, dRnY), dW, dH);
        }
      }

      if (showDots) {
        fill(32, 128, 64, 128);
        for (int i=0; i<weeks[n]; i++) {
          float tX = map(random(100), 0, 100, -halfSizeGap, halfSizeGap);
          float tY = map(random(100), 0, 100, -halfSizeGap, halfSizeGap);
          circle(tX, tY, 6);
        }
      }
      
      if (showSquares) {
        float dMax =bMax;
        if (veraFill) {
          dMax = weeks[n];
        }
        float  dRnX = map(mouseX, 0, width, 0, 15);
        float  dRnY = map(mouseY, 0, height, 0, 15);
        for (int i=0; i<weeks[n]; i++) {
          float d = map(i, 0, dMax, rZ/2f-1, 1);
          float dW = d+random(-dRnY, dRnY);
          float dH = d+random(-dRnX, dRnX);
          noFill();
          stroke(random(8, 128), random(128, 255));
          quad(
          -d+random(-dRnX, dRnX),-d+random(-dRnY, dRnY),
          d+random(-dRnX, dRnX),-d+random(-dRnY, dRnY),
          d+random(-dRnX, dRnX),d+random(-dRnY, dRnY),
          -d+random(-dRnX, dRnX),d+random(-dRnY, dRnY)
          );
        }
      }
    }
    popMatrix();
  }
}
