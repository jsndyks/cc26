// -- Reads data into the weeks arrays by counting the number of times each week is included: 

void readData() {
  
  // -- Each array element contains a line from the file:
  String [] lines = loadStrings("surveyData.txt");
  
  int i=0;
  // -- Loop through each of the lines in turn:
  for (String line : lines) {
    // -- Ignore the header line:
    if (i>0) {
      // -- Split the line at each TAB character and put each token / word into the 'tokens' array:
      String [] tokens = split(line,"\t");
      // -- Use 'trim()' to remove any spaces fromm the string containing the number and convert to aninteger: 
      int  n = int(trim(tokens[0]));
      int w1 = int(trim(tokens[1]));
      int w2 = int(trim(tokens[2]));
      int w3 = int(trim(tokens[3]));

      // -- Add 1 to the count for that week in each of the 'weeks' arrays:
      week1[w1]++;
      week2[w2]++;
      week3[w3]++;
      weeks[w1]++;
      weeks[w2]++;
      weeks[w3]++;
    }
    i++;
  }
  // -- empty weeks[0] - these are null entries;
  weeks[0]=0;
  // -- Check the content of 'weeks':
  //printArray(weeks);
}
